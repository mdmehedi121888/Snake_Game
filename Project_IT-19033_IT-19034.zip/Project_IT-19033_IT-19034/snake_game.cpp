//header file section

#include<graphics.h>
#include<time.h>
#include<stdio.h>
#include<windows.h>
#include<stdlib.h>
#include<fstream>
#include<bits/stdc++.h>
using namespace std;

//function call

void game();
void rules();
void help();
void high();

//global variable

    char ch,ch1[100],ar[100];
    int cursor_y=140,i,X[100],Y[100],rx,ry,l,d=2,s=16,score,highscore;
    
    //------main function--------
    
    
int main()
{
	int gd,gm;
	srand(time(NULL));
	detectgraph(&gd,&gm);
	initgraph(&gd,&gm,"");
	setcolor(3);
    settextstyle(10,0,5);
    
    //homepage
    
    outtextxy(70,2," Project: Snake Game");
    settextstyle(10,0,3);
    setcolor(7);
    outtextxy(00,80," Submitted by:");
    outtextxy(30,120,"Shovan Saha");
    outtextxy(30,145,"IT-19033");
    outtextxy(30,170,"Md.Mehedi Hasan");
    outtextxy(30,195,"IT-19034");
    outtextxy(00,260," Submitted to: ");
    outtextxy(30,300,"Mr. Nazrul Islam Sir ");
    outtextxy(30,320,"Assistant Professor");
    outtextxy(30,340,"ICT,MBSTU");
    setcolor(YELLOW);
    settextstyle(8,HORIZ_DIR,3);
    outtextxy(160,400,"Press any key to continue");
    getch();
    cleardevice();
    
    
    while(1)
    {
        setcolor(3);
        settextstyle(10,HORIZ_DIR,6);
        
        //section page
        
        outtextxy(170,50,"Snake Game");
        setcolor(GREEN);
        settextstyle(6,HORIZ_DIR,2);
        outtextxy(200,140,"New game");
        outtextxy(200,180,"Rules");
        outtextxy(200,220,"Help");
        outtextxy(200,260,"High Score");
        outtextxy(200,300,"Exit");

        setcolor(BLUE);
        settextstyle(3,0,3);
        outtextxy(170,cursor_y,">");

        if(kbhit)
        {
            ch=getch();
            setcolor(BLACK);
            settextstyle(3,0,3);
            outtextxy(170,cursor_y,">");


            if(ch==13)
            {
                if(cursor_y==300)
                    exit(0);
                else if(cursor_y==140)
                    game();
                else if(cursor_y==180)
                    rules();
                else if(cursor_y==220)
                    help();
                else if(cursor_y==260)
                    high();
            }

        }

        if(ch==80)
        {
            cursor_y+=40;
            if(cursor_y>300)
                cursor_y=140;
        }
        if(ch==72)
        {
            cursor_y-=40;
            if(cursor_y<140)
                cursor_y=300;
        }
        settextstyle(3,0,3);
        outtextxy(170,cursor_y,">");
    }
    return 0;
}

//game fuction 

void game()
{
	cleardevice();
	clearviewport();
	freopen("game.txt","r",stdin);
    cin>>highscore;
	setfillstyle(1,1);
	//-----creating boundary-----
	bar(s-s/2,s-s/2,(s/2)+s*(630/s),s+s/2);//top
	bar(s-s/2,(-s/2)+s*(470/s),(s/2)+s*(630/s),(s/2)+s*(470/s));//bottom
	bar(s-s/2,s-s/2,s+s/2,(s/2)+s*(470/s));//left
	bar((-s/2)+s*(630/s),s-s/2,(s/2)+s*(630/s),(s/2)+s*(470/s));//right
	X[0]=s*(630/(2*s));
	Y[0]=s*(470/(2*s));
	bar(X[0]-s/2,Y[0]-s/2,X[0]+s/2,Y[0]+s/2);
	l=5;
	for(i=1;i<l;i++)
	{
		X[i]=X[0]-(i*s);
		Y[i]=Y[0];
		bar(X[i]-s/2,Y[i]-s/2,X[i]+s/2,Y[i]+s/2);
	}
	rx=s;ry=s;
	setfillstyle(1,2);
	while(getpixel(rx,ry)!=0)
	{
		rx=s*(1+rand()%(630/s-1));//generating random food
		ry=s*(1+rand()%(470/s-1));
	}
	bar(rx-s/2,ry-s/2,rx+s/2,ry+s/2);
	delay(2000);
	while(1)
	{
		//updating the snake
		setfillstyle(1,0);
		bar(X[l-1]-s/2,Y[l-1]-s/2,X[l-1]+s/2,Y[l-1]+s/2);
		for(i=l;i>0;i--)
		{
			X[i]=X[i-1];
			Y[i]=Y[i-1];
		}
		//updating the head
		if(d==0)
		X[0]=X[0]-s;
		else if(d==1)
		Y[0]=Y[0]-s;
		else if(d==2)
		X[0]=X[0]+s;
		else if(d==3)
		Y[0]=Y[0]+s;
		//terminating condition
		if(getpixel(X[0],Y[0])==1)
		break;
		//updating direction
		if(GetAsyncKeyState(VK_RIGHT)&&d!=0){
			d=2;
		}
	else if(GetAsyncKeyState(VK_LEFT)&&d!=2){
			d=0;
		}
	else if(GetAsyncKeyState(VK_UP)&&d!=3){
			d=1;
		}
	else if(GetAsyncKeyState(VK_DOWN)&&d!=1){
			d=3;
		}
		if(getpixel(X[0],Y[0])==2)
		{
			rx=s;ry=s;
	setfillstyle(1,2);
	while(getpixel(rx,ry)!=0)
	{
		rx=s*(1+rand()%(630/s-1));
		ry=s*(1+rand()%(470/s-1));
	}
	bar(rx-s/2,ry-s/2,rx+s/2,ry+s/2);
	l=l+1;
		}
		//displaying the snake
		setfillstyle(1,1);
		for(i=0;i<l;i++)
		bar(X[i]-s/2,Y[i]-s/2,X[i]+s/2,Y[i]+s/2);
		delay(100);  
	}
	cleardevice();
	char ch1[100];
	setcolor(YELLOW);
	settextstyle(4,0,4);
	outtextxy(180,150,"!! Game over !!");
	sprintf(ch1,"score : %d",l-5);
	score = l-5;
		setcolor(CYAN);
	settextstyle(4,0,5);
	outtextxy(180,200,ch1);
	if(score == 0)
	{
		//char ch=getch();
		delay(2000);
        clearviewport();
        return;
	}
	//closegraph();
	freopen("game.txt","w",stdout);//creating a file and write mood..
    if(highscore<score)
    {
        cout<<score<<endl;
    }
    else
        cout<<highscore<<endl;

    freopen("game.dat","r",stdin);
    cin>>highscore;
    

	delay(1000);
	cleardevice();
	//while(!GetAsyncKeyState(VK_RETURN));
  char ch=getch();
    clearviewport();
	return ;
}

//rules function

void rules()
{
	clearviewport();
    setcolor(WHITE);
    outtextxy(150,150,"Do not cross the boundary.");
    outtextxy(150,180,"If you cross the boundary, you will die.");
    outtextxy(150,210,"Don't touch snake body by the snake head.");
    outtextxy(150,240,"If you touch snake body, you will die.");
    char ch=getch();
    clearviewport();
    return;
}

//help function

void help()
{
	 clearviewport();
    setcolor(WHITE);
    outtextxy(150,150,"Use  ->  to move the snake to the right.");
    outtextxy(150,180,"Use  <-  to move the snake to the left.");
    outtextxy(150,210,"Use  ^ to move the snake to the up.");
    outtextxy(150,240,"Use  v  to move the snake to the down.");
    char ch=getch();
    clearviewport();
    return;
}

//high score function

void high()
{
	clearviewport();
	freopen("game.txt","r",stdin);
    cin>>highscore;
    char arr[100];
    sprintf(arr,"Highscore = %d",highscore);
    setcolor(MAGENTA);
    settextstyle(4,0,4);
	outtextxy(140,200,arr);
	char ch=getch();
    clearviewport();
    return;
}

//----------the end----------//
//----------thank you-------//


